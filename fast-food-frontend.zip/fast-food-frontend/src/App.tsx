import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight, Check, ChefHat, ChevronDown, Clock3, Heart, MapPin, Menu, Minus,
  Plus, Search, ShoppingBag, SlidersHorizontal, Star, Trash2, Truck, X, Zap
} from 'lucide-react'

type Category = 'Barchasi' | 'Pizza' | 'Burger' | 'Lavash' | 'Hot-dog' | 'Fri' | 'Tovuq' | 'Ichimliklar' | 'Desertlar'
type Product = {
  id: number; name: string; category: Exclude<Category, 'Barchasi'>; description: string
  price: number; image: string; rating: number; popular?: boolean; sizes?: {label:string; price:number}[]
}
type CartItem = { key: string; product: Product; qty: number; size?: string; extras: string[]; unitPrice: number }
const products: Product[] = [
  {id:1,name:'Pepperoni Classic',category:'Pizza',description:'Mol go‘shti pepperoni, mozzarella va maxsus sous',price:45000,image:'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=900&q=85',rating:4.9,popular:true,sizes:[{label:'25 sm',price:45000},{label:'30 sm',price:60000},{label:'35 sm',price:80000}]},
  {id:2,name:'Four Cheese',category:'Pizza',description:'To‘rt xil pishloq va qaymoqli sous',price:52000,image:'https://images.unsplash.com/photo-1571407970349-bc81e7e96d47?w=900&q=85',rating:4.8,sizes:[{label:'25 sm',price:52000},{label:'30 sm',price:68000},{label:'35 sm',price:85000}]},
  {id:3,name:'BBQ Chicken',category:'Pizza',description:'Tovuq, BBQ sous, piyoz va mozzarella',price:49000,image:'https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?w=900&q=85',rating:4.7,sizes:[{label:'25 sm',price:49000},{label:'30 sm',price:64000},{label:'35 sm',price:82000}]},
  {id:4,name:'Double Smash',category:'Burger',description:'Ikki kotlet, cheddar, karamellashgan piyoz',price:42000,image:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=85',rating:4.9,popular:true},
  {id:5,name:'Classic Burger',category:'Burger',description:'Mol go‘shti kotleti, pomidor va maxsus sous',price:32000,image:'https://images.unsplash.com/photo-1553979459-d2229ba7433a?w=900&q=85,rating:4.6},
  {id:6,name:'Maxi Lavash',category:'Lavash',description:'Mol go‘shti, yangi sabzavotlar va fri',price:36000,image:'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=900&q=85',rating:4.8,popular:true},
  {id:7,name:'Pishloqli Lavash',category:'Lavash',description:'Pishloq, go‘sht va maxsus sarimsoqli sous',price:39000,image:'https://images.unsplash.com/photo-1561651823-34feb02250e4?w=900&q=85',rating:4.7},
  {id:8,name:'Hot-dog Royal',category:'Hot-dog',description:'Sosiska, cheddar, qarsildoq piyoz va sous',price:25000,image:'https://images.unsplash.com/photo-1612392062798-2dbaa1b3b5f4?w=900&q=85',rating:4.6},
  {id:9,name:'Crispy Fri',category:'Fri',description:'Oltinrang, qarsildoq kartoshka fri',price:18000,image:'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=900&q=85',rating:4.8},
  {id:10,name:'Chicken Wings',category:'Tovuq',description:'Maxsus ziravorlarda pishirilgan qanotchalar',price:39000,image:'https://images.unsplash.com/photo-1527477396000-e27163b481c2?w=900&q=85',rating:4.9},
  {id:11,name:'Cola',category:'Ichimliklar',description:'Muzdek gazlangan ichimlik, 0.5 L',price:10000,image:'https://images.unsplash.com/photo-1554866585-cd94860890b7?w=900&q=85',rating:4.7},
  {id:12,name:'Chocolate Brownie',category:'Desertlar',description:'Yumshoq shokoladli desert',price:22000,image:'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=900&q=85',rating:4.9}
]
const categories: {name:Category; icon:string}[] = [
  {name:'Barchasi',icon:'✨'},{name:'Pizza',icon:'🍕'},{name:'Burger',icon:'🍔'},{name:'Lavash',icon:'🌯'},
  {name:'Hot-dog',icon:'🌭'},{name:'Fri',icon:'🍟'},{name:'Tovuq',icon:'🍗'},{name:'Ichimliklar',icon:'🥤'},{name:'Desertlar',icon:'🍰'}
]
const extras = [{name:'Qo‘shimcha pishloq',price:7000},{name:'Qo‘ziqorin',price:5000},{name:'Kolbasa',price:8000},{name:'Zaytun',price:4000},{name:'Pomidor',price:3000}]
const money = (n:number) => new Intl.NumberFormat('uz-UZ').format(n) + ' so‘m'
function read<T,>(key:string, fallback:T):T { try { const v=localStorage.getItem(key); return v ? JSON.parse(v) as T : fallback } catch { return fallback } }

export default function App() {
  const [category,setCategory] = useState<Category>('Barchasi')
  const [search,setSearch] = useState('')
  const [cart,setCart] = useState<CartItem[]>(()=>read('ff-cart',[]))
  const [favorites,setFavorites] = useState<number[]>(()=>read('ff-favorites',[]))
  const [cartOpen,setCartOpen] = useState(false)
  const [checkout,setCheckout] = useState(false)
  const [admin,setAdmin] = useState(false)
  const [account,setAccount] = useState(false)
  const [toast,setToast] = useState('')
  const [promo,setPromo] = useState('')
  const [promoApplied,setPromoApplied] = useState(false)
  const [mobileMenu,setMobileMenu] = useState(false)
  const [orders,setOrders] = useState<any[]>(()=>read('ff-orders',[]))
  const [form,setForm] = useState({name:'',phone:'',city:'Toshkent',district:'',address:'',delivery:'Yetkazib berish',payment:'Naqd pul',note:''})
  const [adminProducts,setAdminProducts] = useState<Product[]>(()=>read('ff-products',products))

  useEffect(()=>localStorage.setItem('ff-cart',JSON.stringify(cart)),[cart])
  useEffect(()=>localStorage.setItem('ff-favorites',JSON.stringify(favorites)),[favorites])
  useEffect(()=>localStorage.setItem('ff-orders',JSON.stringify(orders)),[orders])
  useEffect(()=>localStorage.setItem('ff-products',JSON.stringify(adminProducts)),[adminProducts])
  useEffect(()=>{ if(!toast)return; const t=setTimeout(()=>setToast(''),2600); return ()=>clearTimeout(t)},[toast])

  const filtered = useMemo(()=>adminProducts.filter(p=>(category==='Barchasi'||p.category===category)&&(`${p.name} ${p.description}`).toLowerCase().includes(search.toLowerCase())),[category,search,adminProducts])
  const subtotal = cart.reduce((s,i)=>s+i.unitPrice*i.qty,0)
  const discount = promoApplied ? Math.round(subtotal*.10) : 0
  const deliveryFee = form.delivery==='Olib ketish' ? 0 : subtotal>=100000 ? 0 : 10000
  const total = Math.max(0,subtotal-discount+deliveryFee)
  const count = cart.reduce((s,i)=>s+i.qty,0)

  function addToCart(product:Product,size?:string,chosenExtras:string[]=[]){
    const base = size ? product.sizes?.find(s=>s.label===size)?.price ?? product.price : product.price
    const extraCost = chosenExtras.reduce((sum,n)=>sum+(extras.find(e=>e.name===n)?.price??0),0)
    const key = `${product.id}-${size??'std'}-${chosenExtras.join('|')}`
    setCart(old=>{const found=old.find(i=>i.key===key);return found?old.map(i=>i.key===key?{...i,qty:i.qty+1}:i):[...old,{key,product,qty:1,size,extras:chosenExtras,unitPrice:base+extraCost}]})
    setToast(`${product.name} savatga qo‘shildi`)
  }
  function changeQty(key:string,delta:number){setCart(old=>old.map(i=>i.key===key?{...i,qty:i.qty+delta}:i).filter(i=>i.qty>0))}
  function toggleFavorite(id:number){setFavorites(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id])}
  function applyPromo(){if(promo.trim().toUpperCase()==='MAZALI10'&&subtotal>0){setPromoApplied(true);setToast('10% chegirma qo‘llanildi')}else{setPromoApplied(false);setToast('Promo-kod noto‘g‘ri yoki savat bo‘sh')}}
  function submitOrder(e:FormEvent){e.preventDefault();if(!form.name||!form.phone||!form.address||!cart.length){setToast('Iltimos, majburiy maydonlarni to‘ldiring');return}
    const order={id:'FF-'+Date.now().toString().slice(-7),date:new Date().toLocaleString('uz-UZ'),items:cart,total,status:'Yangi buyurtma',customer:form}
    setOrders(old=>[order,...old]);setCart([]);setPromoApplied(false);setPromo('');setCheckout(false);setCartOpen(false);setToast(`Buyurtma ${order.id} qabul qilindi`)}
  function updateProduct(id:number,patch:Partial<Product>){setAdminProducts(old=>old.map(p=>p.id===id?{...p,...patch}:p))}
  function deleteProduct(id:number){setAdminProducts(old=>old.filter(p=>p.id!==id));setToast('Mahsulot o‘chirildi')}

  return <div className="min-h-screen bg-[#f7f6f3] text-[#171717]">
    <div className="topline"><div className="container flex justify-between"><span><Zap size={13}/> 100 000 so‘mdan yuqori buyurtmaga yetkazib berish bepul</span><span className="hidden sm:block">Har kuni 10:00 — 23:00</span></div></div>
    <header className="nav-wrap">
      <div className="container nav">
        <a href="#" className="brand" onClick={()=>{setAdmin(false);setCategory('Barchasi')}}><span className="brand-mark">FF</span><span>FAST<span className="brand-red">FOOD.</span><small>MAZALI TANLOV</small></span></a>
        <nav className="desktop-nav"><a href="#home">Bosh sahifa</a><a href="#menu">Menyu</a><a href="#offers">Aksiyalar</a><a href="#about">Biz haqimizda</a><a href="#contact">Aloqa</a></nav>
        <div className="nav-actions">
          <button className="icon-btn" aria-label="Qidiruv" onClick={()=>document.getElementById('searchbox')?.focus()}><Search size={19}/></button>
          <button className="icon-btn" aria-label="Sevimlilar" onClick={()=>{setCategory('Barchasi');setSearch('');setToast(`Sevimlilar: ${favorites.length} ta`)}}><Heart size={19}/><i>{favorites.length}</i></button>
          <button className="cart-nav" onClick={()=>setCartOpen(true)}><ShoppingBag size={17}/><span>Savat</span><b>{count}</b></button>
          <button className="account-btn" onClick={()=>setAccount(true)}>Kirish <ArrowRight size={15}/></button>
          <button className="mobile-toggle" onClick={()=>setMobileMenu(!mobileMenu)}><Menu/></button>
        </div>
      </div>
      {mobileMenu&&<div className="mobile-menu"><a href="#home" onClick={()=>setMobileMenu(false)}>Bosh sahifa</a><a href="#menu" onClick={()=>setMobileMenu(false)}>Menyu</a><a href="#offers" onClick={()=>setMobileMenu(false)}>Aksiyalar</a><a href="#about" onClick={()=>setMobileMenu(false)}>Biz haqimizda</a><button onClick={()=>{setAdmin(true);setMobileMenu(false)}}>Admin demo</button></div>}
    </header>

    {!admin ? <>
    <main>
      <section id="home" className="hero container">
        <div className="hero-copy">
          <div className="eyebrow"><span/> TOSHKENT BO‘YLAB YETKAZAMIZ</div>
          <h1>Mazali ta’m.<br/><em>Tezkor</em> yetkazib berish.</h1>
          <p>Sevimli taomlaringiz — yangi, issiq va aynan siz xohlagandek. Bir necha bosishda buyurtma bering.</p>
          <div className="hero-actions"><a className="primary-btn" href="#menu">Menyuni ko‘rish <ArrowRight size={18}/></a><div className="delivery-note"><span className="delivery-icon"><Truck size={18}/></span><span><b>30–45 daqiqa</b><small>O‘rtacha yetkazish vaqti</small></span></div></div>
          <div className="hero-stats"><div><b>4.9<span>★</span></b><small>Mijozlar bahosi</small></div><div><b>12k+</b><small>Mamnun mijozlar</small></div><div><b>25+</b><small>Mazali tanlov</small></div></div>
        </div>
        <div className="hero-visual"><div className="hero-orbit"></div><div className="hero-image"><img src="https://images.unsplash.com/photo-1579751626657-72bc17010498?w=1200&q=90" alt="Mazali pepperoni pizza"/></div><div className="floating-tag tag-top"><span>🔥</span><div><b>TOP TANLOV</b><small>Pepperoni pizza</small></div></div><div className="floating-tag tag-bottom"><div className="round-star">★</div><div><b>4.9 / 5.0</b><small>Haqiqiy ta’m bahosi</small></div></div><div className="hero-sticker">HOT<br/> & FRESH</div></div>
      </section>

      <section id="offers" className="offer-strip container"><div className="offer-icon">🍕</div><div><small>BUGUNGI MAXSUS TAKLIF</small><h3>MAZALI10 — 10% chegirma</h3><p>Birinchi buyurtmangiz uchun maxsus taklif</p></div><button onClick={()=>{setPromo('MAZALI10');setCartOpen(true)}}>Kodni ishlatish <ArrowRight size={16}/></button><div className="offer-watermark">10%</div></section>

      <section id="menu" className="menu-section container">
        <div className="section-heading"><div><div className="eyebrow"><span/> BIZNING MENYU</div><h2>Och qoldingizmi?</h2><p>Kayfiyatingizga mos mazali tanlovni toping.</p></div><div className="menu-tools"><div className="search-box"><Search size={17}/><input id="searchbox" placeholder="Taom qidirish..." value={search} onChange={e=>setSearch(e.target.value)}/><SlidersHorizontal size={16}/></div></div></div>
        <div className="category-row">{categories.map(c=><button key={c.name} className={category===c.name?'category active':'category'} onClick={()=>setCategory(c.name)}><span>{c.icon}</span>{c.name}</button>)}</div>
        <div className="product-grid">
          {filtered.map((p,index)=><ProductCard key={p.id} product={p} index={index} favorite={favorites.includes(p.id)} onFavorite={()=>toggleFavorite(p.id)} onAdd={(size,chosen)=>addToCart(p,size,chosen)}/>)}
        </div>
        {filtered.length===0&&<div className="empty-results"><span>🍽️</span><h3>Hech narsa topilmadi</h3><p>Boshqa nom bilan qidirib ko‘ring.</p><button onClick={()=>{setSearch('');setCategory('Barchasi')}}>Filtrni tozalash</button></div>}
      </section>

      <section id="about" className="why-section"><div className="container"><div className="section-heading centered"><div className="eyebrow"><span/> NEGA AYNAN BIZ?</div><h2>Har luqmada <em>zavq</em></h2><p>Biz uchun mazali taom — bu shunchaki ovqat emas, kayfiyat ulashish.</p></div><div className="benefit-grid"><div className="benefit"><div>🥬</div><h3>Yangi mahsulotlar</h3><p>Har kuni saralangan, sifatli masalliqlardan foydalanamiz.</p></div><div className="benefit"><div>⚡</div><h3>Tezkor yetkazish</h3><p>Buyurtmangizni issiq va vaqtida yetkazishga intilamiz.</p></div><div className="benefit"><div>👨‍🍳</div><h3>Usta oshpazlar</h3><p>Har bir taom mehr va e’tibor bilan tayyorlanadi.</p></div><div className="benefit"><div>❤️</div><h3>Mijozlar roziligi</h3><p>Sizning fikringiz biz uchun doimo birinchi o‘rinda.</p></div></div></div></section>
    </main>
    <footer id="contact"><div className="container footer-inner"><div className="brand footer-brand"><span className="brand-mark">FF</span><span>FAST<span className="brand-red">FOOD.</span><small>MAZALI TANLOV</small></span></div><p>Mazali ta’m — tezkor yetkazib berish.</p><div className="footer-contact"><span><MapPin size={15}/> Toshkent, O‘zbekiston</span><span><Clock3 size={15}/> 10:00 — 23:00</span><span>+998 90 123 45 67</span></div><div className="footer-bottom"><span>© 2026 FAST FOOD. Barcha huquqlar himoyalangan.</span><button onClick={()=>setAdmin(true)}>Admin panel ↗</button></div></div></footer>
    </> : <AdminPanel products={adminProducts} orders={orders} onBack={()=>setAdmin(false)} onDelete={deleteProduct} onUpdate={updateProduct} onStatus={(id,status)=>setOrders(old=>old.map(o=>o.id===id?{...o,status}:o))} onAdd={()=>{const p:Product={id:Date.now(),name:'Yangi mahsulot',category:'Burger',description:'Mahsulot tavsifi',price:25000,image:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=85',rating:5};setAdminProducts(old=>[p,...old]);setToast('Yangi mahsulot qo‘shildi')}}/>}
    <AnimatePresence>{cartOpen&&<><motion.div className="overlay" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={()=>setCartOpen(false)}/><motion.aside className="cart-drawer" initial={{x:'100%'}} animate={{x:0}} exit={{x:'100%'}} transition={{type:'spring',damping:28}}><div className="drawer-head"><div><small>SIZNING TANLOVINGIZ</small><h2>Savat <span>({count})</span></h2></div><button className="close-btn" onClick={()=>setCartOpen(false)}><X/></button></div>
      {cart.length===0?<div className="empty-cart"><div>🛍️</div><h3>Savatingiz hozircha bo‘sh</h3><p>Menyudan o‘zingiz yoqtirgan taomlarni tanlang.</p><button className="primary-btn" onClick={()=>setCartOpen(false)}>Menyuga qaytish <ArrowRight size={16}/></button></div>:<>
      <div className="cart-items">{cart.map(i=><div className="cart-item" key={i.key}><img src={i.product.image} alt={i.product.name}/><div className="cart-item-info"><b>{i.product.name}</b>{i.size&&<small>Hajmi: {i.size}</small>}{i.extras.length>0&&<small>{i.extras.join(', ')}</small>}<strong>{money(i.unitPrice*i.qty)}</strong><div className="qty"><button onClick={()=>changeQty(i.key,-1)}><Minus size={13}/></button><b>{i.qty}</b><button onClick={()=>changeQty(i.key,1)}><Plus size={13}/></button></div></div><button className="remove" onClick={()=>setCart(old=>old.filter(x=>x.key!==i.key))}><Trash2 size={16}/></button></div>)}</div>
      <div className="cart-bottom"><div className="promo-row"><input placeholder="Promo-kod" value={promo} onChange={e=>setPromo(e.target.value)}/><button onClick={applyPromo}>Qo‘llash</button></div>{promoApplied&&<small className="success-line"><Check size={13}/> 10% chegirma qo‘llanildi</small>}<div className="summary-line"><span>Mahsulotlar</span><b>{money(subtotal)}</b></div>{discount>0&&<div className="summary-line discount"><span>Chegirma</span><b>− {money(discount)}</b></div>}<div className="summary-line"><span>Yetkazib berish</span><b>{deliveryFee===0?'Bepul':money(deliveryFee)}</b></div><div className="summary-total"><span>Jami</span><b>{money(total)}</b></div><button className="primary-btn checkout-btn" onClick={()=>setCheckout(true)}>Buyurtma berish <ArrowRight size={18}/></button><p className="secure-note">🔒 Buyurtma ma’lumotlari ushbu brauzerda saqlanadi</p></div></>}</motion.aside></>}</AnimatePresence>}

    <AnimatePresence>{checkout&&<Modal onClose={()=>setCheckout(false)} title="Buyurtmani rasmiylashtirish"><form className="checkout-form" onSubmit={submitOrder}><div className="form-grid"><label>Ism va familiya *<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Ismingiz"/></label><label>Telefon raqami *<input required type="tel" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="+998 90 123 45 67"/></label><label>Shahar / viloyat<select value={form.city} onChange={e=>setForm({...form,city:e.target.value})}><option>Toshkent</option><option>Samarqand</option><option>Buxoro</option><option>Andijon</option><option>Farg‘ona</option><option>Namangan</option><option>Boshqa</option></select></label><label>Tuman<input value={form.district} onChange={e=>setForm({...form,district:e.target.value})} placeholder="Tuman nomi"/></label></div><label>Ko‘cha va uy manzili *<input required value={form.address} onChange={e=>setForm({...form,address:e.target.value})} placeholder="Ko‘cha, uy, xonadon"/></label><div className="form-two"><label>Olish usuli<select value={form.delivery} onChange={e=>setForm({...form,delivery:e.target.value})}><option>Yetkazib berish</option><option>Olib ketish</option></select></label><label>To‘lov usuli<select value={form.payment} onChange={e=>setForm({...form,payment:e.target.value})}><option>Naqd pul</option><option>Click (demo)</option><option>Payme (demo)</option><option>Uzcard / Humo (demo)</option></select></label></div><label>Izoh<textarea rows={2} value={form.note} onChange={e=>setForm({...form,note:e.target.value})} placeholder="Buyurtma bo‘yicha qo‘shimcha izoh..."/></label><div className="checkout-total"><span>To‘lov summasi</span><b>{money(total)}</b></div><p className="demo-warning">Eslatma: bu frontend demo. Elektron to‘lovlar amalga oshirilmaydi va karta ma’lumotlari so‘ralmaydi.</p><button className="primary-btn full-btn" type="submit">Buyurtmani tasdiqlash <ArrowRight size={17}/></button></form></Modal>}</AnimatePresence>
    <AnimatePresence>{account&&<Modal onClose={()=>setAccount(false)} title="Shaxsiy kabinet"><div className="account-content"><div className="account-avatar">👤</div><h3>Xush kelibsiz!</h3><p>Demo kabinet: buyurtmalaringiz shu brauzerda saqlanadi.</p><div className="order-history"><h4>Buyurtmalar tarixi</h4>{orders.length===0?<p>Hozircha buyurtmalar yo‘q.</p>:orders.map(o=><div className="history-row" key={o.id}><span><b>{o.id}</b><small>{o.date}</small></span><span><b>{money(o.total)}</b><small>{o.status}</small></span></div>)}</div><button className="secondary-btn" onClick={()=>{setAccount(false);setAdmin(true)}}>Admin demo paneli</button></div></Modal>}</AnimatePresence>
    <AnimatePresence>{toast&&<motion.div className="toast" initial={{y:30,opacity:0}} animate={{y:0,opacity:1}} exit={{y:20,opacity:0}}><Check size={17}/>{toast}</motion.div>}</AnimatePresence>
  </div>
}

function ProductCard({product,index,favorite,onFavorite,onAdd}:{product:Product;index:number;favorite:boolean;onFavorite:()=>void;onAdd:(size?:string,extras?:string[])=>void}){
  const [size,setSize]=useState(product.sizes?.[1]?.label??'')
  const [chosen,setChosen]=useState<string[]>([])
  const [customize,setCustomize]=useState(false)
  const price=product.sizes?.find(s=>s.label===size)?.price??product.price
  const extraPrice=chosen.reduce((s,n)=>s+(extras.find(e=>e.name===n)?.price??0),0)
  return <motion.article className="product-card" initial={{opacity:0,y:18}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.1}} transition={{delay:(index%4)*.06}}>
    <div className="product-image"><img src={product.image} alt={product.name} loading="lazy"/>{product.popular&&<span className="popular-label">★ TOP TANLOV</span>}<button className={`favorite-btn ${favorite?'liked':''}`} onClick={onFavorite}><Heart size={17} fill={favorite?'currentColor':'none'}/></button></div>
    <div className="product-body"><div className="product-meta"><span>{product.category}</span><span><Star size={13} fill="#f5a623" stroke="#f5a623"/> {product.rating}</span></div><h3>{product.name}</h3><p>{product.description}</p>
      {product.sizes&&<div className="size-select"><small>PIZZA HAJMI</small><div>{product.sizes.map(s=><button key={s.label} className={size===s.label?'selected':''} onClick={()=>setSize(s.label)}>{s.label}</button>)}</div></div>}
      {product.sizes&&<button className="extras-toggle" onClick={()=>setCustomize(!customize)}>{customize?'Qo‘shimchalarni yopish':'Ingredient qo‘shish'} <ChevronDown size={14}/></button>}
      <AnimatePresence>{customize&&<motion.div className="extras-list" initial={{height:0,opacity:0}} animate={{height:'auto',opacity:1}} exit={{height:0,opacity:0}}>{extras.map(e=><label key={e.name}><input type="checkbox" checked={chosen.includes(e.name)} onChange={ev=>setChosen(old=>ev.target.checked?[...old,e.name]:old.filter(x=>x!==e.name))}/><span>{e.name}</span><small>+{money(e.price)}</small></label>)}</motion.div>}</AnimatePresence>
      <div className="product-buy"><div><small>NARXI</small><b>{money(price+extraPrice)}</b></div><button onClick={()=>onAdd(product.sizes?size:undefined,chosen)} aria-label="Savatga qo‘shish"><Plus size={20}/></button></div>
    </div>
  </motion.article>
}

function Modal({children,onClose,title}:{children:ReactNode;onClose:()=>void;title:string}){
 return <motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}><motion.div className="modal" initial={{y:24,opacity:0,scale:.98}} animate={{y:0,opacity:1,scale:1}} exit={{y:20,opacity:0}} onClick={e=>e.stopPropagation()}><div className="modal-head"><h2>{title}</h2><button className="close-btn" onClick={onClose}><X/></button></div>{children}</motion.div></motion.div>
}
function AdminPanel({products,orders,onBack,onDelete,onUpdate,onAdd,onStatus}:{products:Product[];orders:any[];onBack:()=>void;onDelete:(id:number)=>void;onUpdate:(id:number,p:Partial<Product>)=>void;onAdd:()=>void;onStatus:(id:string,status:string)=>void}){
 const [tab,setTab]=useState<'overview'|'products'|'orders'>('overview')
 const revenue=orders.reduce((s,o)=>s+o.total,0)
 return <main className="admin-page"><div className="admin-top"><div><span className="brand-mark">FF</span><b>FAST FOOD <small>ADMIN</small></b></div><button className="secondary-btn" onClick={onBack}>← Saytga qaytish</button></div><div className="container admin-content"><div className="admin-title"><div><div className="eyebrow"><span/> BOSHQARUV PANELI</div><h1>Dashboard</h1><p>Do‘koningiz faoliyatini boshqaring.</p></div><span className="demo-chip">DEMO REJIM</span></div><div className="admin-tabs">{(['overview','products','orders'] as const).map(t=><button className={tab===t?'active':''} onClick={()=>setTab(t)}>{t==='overview'?'Umumiy':t==='products'?'Mahsulotlar':'Buyurtmalar'}</button>)}</div>
 {tab==='overview'&&<><div className="admin-stats"><div><small>JAMI MAHSULOTLAR</small><b>{products.length}</b><span>Faol menyu</span></div><div><small>BUYURTMALAR</small><b>{orders.length}</b><span>Jami buyurtma</span></div><div><small>JAMI TUSHUM</small><b>{money(revenue)}</b><span>Demo buyurtmalar</span></div></div><div className="admin-panel-card"><h3>So‘nggi buyurtmalar</h3>{orders.length===0?<p>Hozircha buyurtmalar mavjud emas.</p>:orders.slice(0,5).map(o=><div className="admin-order" key={o.id}><b>{o.id}</b><span>{o.customer.name}</span><b>{money(o.total)}</b><span className="status">{o.status}</span></div>)}</div></>}
 {tab==='products'&&<div className="admin-panel-card"><div className="admin-card-head"><h3>Mahsulotlar ({products.length})</h3><button className="primary-btn compact" onClick={onAdd}><Plus size={15}/> Mahsulot qo‘shish</button></div>{products.map(p=><div className="admin-product" key={p.id}><img src={p.image} alt=""/><div><b>{p.name}</b><small>{p.category}</small></div><input aria-label="Narx" type="number" value={p.price} onChange={e=>onUpdate(p.id,{price:Number(e.target.value)})}/><button className="remove" onClick={()=>onDelete(p.id)}><Trash2 size={16}/></button></div>)}</div>}
 {tab==='orders'&&<div className="admin-panel-card"><h3>Barcha buyurtmalar</h3>{orders.length===0?<p>Buyurtmalar hali yo‘q. Sayt orqali test buyurtma bering.</p>:orders.map(o=><div className="admin-order order-full" key={o.id}><div><b>{o.id}</b><small>{o.customer.name} · {o.customer.phone}</small></div><b>{money(o.total)}</b><select value={o.status} onChange={e=>onStatus(o.id,e.target.value)}>{['Yangi buyurtma','Qabul qilindi','Tayyorlanmoqda','Kuryerga berildi','Yetkazildi','Bekor qilindi'].map(s=><option>{s}</option>)}</select></div>)}</div>}
 <p className="admin-disclaimer">Bu admin panel faqat frontend demo hisoblanadi. O‘zgarishlar joriy brauzerning LocalStorage xotirasida saqlanadi.</p></div></main>
}
